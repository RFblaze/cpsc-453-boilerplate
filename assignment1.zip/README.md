### Controls
**Up/Down Arrow Keys**: Increase/Decrease depth of fractals (min = 0, max = 10)

**Left/Right Arrow Keys**: Switch between scenes. 

Left goes towards scene 1, right goes towards scene 4
- Scene 1 (starts here): Sierpinski Triangle
- Scene 2: Pythagoras Tree
- Scene 3: Koch Snowflake
- Scene 4: Dragon Curve
